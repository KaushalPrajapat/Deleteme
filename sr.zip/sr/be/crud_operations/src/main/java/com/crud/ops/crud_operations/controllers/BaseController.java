package com.crud.ops.crud_operations.controllers;

import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin("*")
@RequestMapping("/api/basic")
public class BaseController {


}
