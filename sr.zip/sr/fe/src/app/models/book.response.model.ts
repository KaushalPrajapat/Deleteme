
export interface BookResponseDto {
  bookId: number;
  bookTitle: string;
  bookDescription: string;
}
