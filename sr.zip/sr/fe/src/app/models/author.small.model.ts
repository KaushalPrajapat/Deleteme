export interface AuthorSmall {
  id: number;
  name: string;
}
