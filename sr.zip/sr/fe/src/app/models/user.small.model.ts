export interface UserSmall{
  id: number;
  name: string;
}
