export interface SuccessMessage {
  message: string;
  successCode: number;
}
