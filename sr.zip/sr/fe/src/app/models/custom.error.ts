export interface CustomError {
  message: string;
  httpStatus: string;
  statusCode: number;
}